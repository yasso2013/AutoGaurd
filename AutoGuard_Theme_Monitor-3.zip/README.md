# AutoGuard — AI Pro Bluetooth Monitor

This version uses a dark dashboard inspired by the supplied AutoGuard AI Pro design.

## Features
- HC-05 classic Bluetooth connection
- Live temperature monitoring
- Live humidity monitoring
- SAFE / DANGER security state
- Sends ON = open all system
- Sends OFF = close all system
- Dark dashboard with cards, status chips, and hardware-style controls

## Arduino data
The app can parse lines such as:
Temperature:26.70
Humidity:55.00
SECURITY:safe

It also accepts `danger` / `safe` in a status line.

If no SECURITY value is received, the app uses the project's 30°C temperature threshold as a fallback:
- Temperature > 30°C -> DANGER
- Otherwise -> SAFE

## Build in GitHub Codespaces
1. Unzip the project.
2. Make sure Android SDK 35 is installed.
3. Set `local.properties`, for example:
   sdk.dir=/home/codespace/android-sdk
4. Run:
   gradle assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk

## Bluetooth
Pair the phone with the HC-05 in Android Bluetooth settings first. Then open AutoGuard, press CONNECT HC-05, and allow Bluetooth permission if Android asks.
