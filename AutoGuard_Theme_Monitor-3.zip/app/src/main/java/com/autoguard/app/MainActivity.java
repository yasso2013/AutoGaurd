package com.autoguard.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_BT = 1001;
    private static final int TEMP_LIMIT = 30;
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    private Thread readerThread;
    private volatile boolean reading = false;

    private TextView tvBluetooth, tvTemp, tvHumidity, tvSecurity, tvSystem;
    private TextView tvTempStatus, tvHumidityStatus, tvLastData, tvResponse, tvLog;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private double lastTemp = Double.NaN;
    private String security = "safe";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvBluetooth = findViewById(R.id.tvBluetooth);
        tvTemp = findViewById(R.id.tvTemp);
        tvHumidity = findViewById(R.id.tvHumidity);
        tvSecurity = findViewById(R.id.tvSecurity);
        tvSystem = findViewById(R.id.tvSystem);
        tvTempStatus = findViewById(R.id.tvTempStatus);
        tvHumidityStatus = findViewById(R.id.tvHumidityStatus);
        tvLastData = findViewById(R.id.tvLastData);
        tvResponse = findViewById(R.id.tvResponse);
        tvLog = findViewById(R.id.tvLog);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        findViewById(R.id.btnConnect).setOnClickListener(v -> requestBluetoothAndConnect());
        findViewById(R.id.btnOn).setOnClickListener(v -> sendCommand("ON"));
        findViewById(R.id.btnOff).setOnClickListener(v -> sendCommand("OFF"));

        setSafeUI();
    }

    private void requestBluetoothAndConnect() {
        if (bluetoothAdapter == null) {
            toast("This phone does not support Bluetooth.");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
            }, REQUEST_BT);
            return;
        }

        connectToHC05();
    }

    private void connectToHC05() {
        new Thread(() -> {
            try {
                if (!bluetoothAdapter.isEnabled()) {
                    runOnUiThread(() -> toast("Turn Bluetooth on first."));
                    return;
                }

                BluetoothDevice target = null;
                Set<BluetoothDevice> bonded = bluetoothAdapter.getBondedDevices();

                for (BluetoothDevice device : bonded) {
                    String name = device.getName();
                    if (name != null && (name.toUpperCase().contains("HC-05")
                            || name.toUpperCase().contains("HC05"))) {
                        target = device;
                        break;
                    }
                }

                if (target == null) {
                    runOnUiThread(() -> toast("Pair HC-05 in Android Bluetooth settings first."));
                    return;
                }

                closeConnection();

                socket = target.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();

                outputStream = socket.getOutputStream();
                inputStream = socket.getInputStream();
                reading = true;

                runOnUiThread(() -> {
                    tvBluetooth.setText("● Bluetooth: CONNECTED");
                    tvBluetooth.setTextColor(getColor(R.color.teal));
                    tvSystem.setText("LIVE MONITORING");
                    tvSystem.setTextColor(getColor(R.color.teal));
                    tvSystem.setBackgroundResource(R.drawable.bg_safe);
                    toast("HC-05 connected");
                });

                startReader();

            } catch (Exception e) {
                closeConnection();
                runOnUiThread(() -> {
                    tvBluetooth.setText("● Bluetooth: OFF");
                    tvSystem.setText("CONNECTION ERROR");
                    tvSystem.setTextColor(getColor(R.color.red));
                    tvSystem.setBackgroundResource(R.drawable.bg_danger);
                    appendLog("Connection error: " + e.getMessage());
                    toast("Could not connect to HC-05");
                });
            }
        }).start();
    }

    private void startReader() {
        readerThread = new Thread(() -> {
            byte[] buffer = new byte[256];
            StringBuilder line = new StringBuilder();

            try {
                while (reading && inputStream != null) {
                    int count = inputStream.read(buffer);
                    if (count <= 0) continue;

                    String incoming = new String(buffer, 0, count);
                    for (char c : incoming.toCharArray()) {
                        if (c == '\n' || c == '\r') {
                            if (line.length() > 0) {
                                final String completeLine = line.toString().trim();
                                line.setLength(0);
                                handler.post(() -> parseArduinoLine(completeLine));
                            }
                        } else {
                            line.append(c);
                        }
                    }
                }
            } catch (IOException ignored) {
                if (reading) {
                    handler.post(() -> {
                        tvBluetooth.setText("● Bluetooth: DISCONNECTED");
                        tvSystem.setText("LINK LOST");
                        tvSystem.setTextColor(getColor(R.color.red));
                        tvSystem.setBackgroundResource(R.drawable.bg_danger);
                    });
                }
            }
        });
        readerThread.start();
    }

    private void parseArduinoLine(String line) {
        appendLog(line);

        String lower = line.toLowerCase();

        if (lower.contains("temperature")) {
            Double value = extractNumberAfterLabel(line, "temperature");
            if (value != null) {
                lastTemp = value;
                tvTemp.setText(String.format(java.util.Locale.US, "%.1f°C", value));
                tvTempStatus.setText(value > TEMP_LIMIT ? "HIGH TEMPERATURE" : "SAFE LEVEL");
                tvTempStatus.setTextColor(getColor(value > TEMP_LIMIT ? R.color.red : R.color.teal));

                if (value > TEMP_LIMIT && !security.equals("danger")) {
                    security = "danger";
                    setDangerUI();
                }
            }
        }

        if (lower.contains("humidity")) {
            Double value = extractNumberAfterLabel(line, "humidity");
            if (value != null) {
                tvHumidity.setText(String.format(java.util.Locale.US, "%.0f %%", value));
                tvHumidityStatus.setText("LIVE FROM ARDUINO");
                tvHumidityStatus.setTextColor(getColor(R.color.cyan));
            }
        }

        if (lower.contains("security")) {
            if (lower.contains("danger")) {
                security = "danger";
                setDangerUI();
            } else if (lower.contains("safe")) {
                security = "safe";
                setSafeUI();
            }
        }

        if (lower.contains("system on") || lower.contains("open all")) {
            tvResponse.setText("Window Servo Motor     OPEN\nCabin Exhaust Fan      ON\nAlarm Siren Buzzer     READY\nParent Alert System    STANDBY");
        } else if (lower.contains("system off") || lower.contains("close all")) {
            tvResponse.setText("Window Servo Motor     CLOSED\nCabin Exhaust Fan      OFF\nAlarm Siren Buzzer     MUTED\nParent Alert System    STANDBY");
        }

        tvLastData.setText("Last Arduino update received");
    }

    private Double extractNumberAfterLabel(String line, String label) {
        int index = line.toLowerCase().indexOf(label.toLowerCase());
        if (index < 0) return null;

        String part = line.substring(index + label.length());
        java.util.regex.Matcher matcher =
                java.util.regex.Pattern.compile("[-+]?\\d+(?:[.,]\\d+)?").matcher(part);

        if (matcher.find()) {
            try {
                return Double.parseDouble(matcher.group().replace(',', '.'));
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    private void sendCommand(String command) {
        if (outputStream == null) {
            toast("Connect to HC-05 first.");
            return;
        }

        new Thread(() -> {
            try {
                outputStream.write((command + "\n").getBytes());
                outputStream.flush();

                runOnUiThread(() -> {
                    if (command.equals("ON")) {
                        tvResponse.setText("Window Servo Motor     OPEN\nCabin Exhaust Fan      ON\nAlarm Siren Buzzer     READY\nParent Alert System    STANDBY");
                        toast("ON sent — open all system");
                    } else {
                        tvResponse.setText("Window Servo Motor     CLOSED\nCabin Exhaust Fan      OFF\nAlarm Siren Buzzer     MUTED\nParent Alert System    STANDBY");
                        toast("OFF sent — close all system");
                    }
                });
            } catch (IOException e) {
                runOnUiThread(() -> toast("Bluetooth send failed."));
            }
        }).start();
    }

    private void setSafeUI() {
        tvSecurity.setText("SAFE");
        tvSecurity.setTextColor(getColor(R.color.teal));
        tvSystem.setText("SYSTEM READY");
        tvSystem.setTextColor(getColor(R.color.teal));
        tvSystem.setBackgroundResource(R.drawable.bg_safe);
    }

    private void setDangerUI() {
        tvSecurity.setText("DANGER");
        tvSecurity.setTextColor(getColor(R.color.red));
        tvSystem.setText("ALERT ACTIVE");
        tvSystem.setTextColor(getColor(R.color.red));
        tvSystem.setBackgroundResource(R.drawable.bg_danger);
    }

    private void appendLog(String line) {
        String current = tvLog.getText().toString();
        String next = current + "\n> " + line;
        if (next.length() > 1400) {
            next = next.substring(next.length() - 1400);
        }
        tvLog.setText(next);
    }

    private void closeConnection() {
        reading = false;
        try { if (inputStream != null) inputStream.close(); } catch (Exception ignored) {}
        try { if (outputStream != null) outputStream.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        inputStream = null;
        outputStream = null;
        socket = null;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BT) {
            boolean granted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    granted = false;
                    break;
                }
            }
            if (granted) connectToHC05();
            else toast("Bluetooth permission is required.");
        }
    }

    @Override
    protected void onDestroy() {
        closeConnection();
        super.onDestroy();
    }
}
